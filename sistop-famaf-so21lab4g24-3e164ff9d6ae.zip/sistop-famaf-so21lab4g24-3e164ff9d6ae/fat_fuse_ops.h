#include <fuse/fuse.h>

struct fuse_operations fat_fuse_operations;

