#ifndef _PROMPT_H_
#define _PROMPT_H_

void show_prompt(void);

#endif
