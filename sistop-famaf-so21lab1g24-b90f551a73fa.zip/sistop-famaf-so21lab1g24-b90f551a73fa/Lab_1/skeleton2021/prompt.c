#include <stdio.h>

#include "prompt.h"

void show_prompt(void){
    printf ("mybash> ");
    fflush (stdout);
}


